import { motion, useScroll, useSpring } from 'framer-motion'

export default function ScrollProgress() {
  const { scrollYProgress } = useScroll()
  const scaleX = useSpring(scrollYProgress, { stiffness: 200, damping: 30 })
  return (
    <motion.div
      className="fixed top-0 left-0 right-0 z-[999] origin-left"
      style={{
        height: 2,
        scaleX,
        background: 'linear-gradient(90deg, #7A44E4, #9B6EFF, #35BBFF)',
      }}
    />
  )
}
